﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LabMVC.DTO
{
    public class LoginDTO
    {
        public string Login { get; set; }
        public string Senha { get; set; }
    }
}